package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
//UPDATE: Added route to return static data with check sum value.

@RestController
class ServerController{
	@RequestMapping("/hash")
	public String theHash() throws NoSuchAlgorithmException {
		String name = "Hamir Aquino";							//Name to be returned.
		
		//MessageDigest object with hash algorithm SHA-1 gets the string name into bytes and is digested into a byte array.
		MessageDigest mssg = MessageDigest.getInstance("SHA-1");
		mssg.update(name.getBytes());
		byte[] digest = mssg.digest();
		
		StringBuffer value = new StringBuffer();			//StringBuffer object stores the byte array into hexadecimal characters.

		//Loop through the byte array and add to the StringBuffer object using 0xFF formatting.
		for (int i = 0; i < digest.length; ++i) {
			value.append(Integer.toHexString(0xFF & digest[i]));
		}
		
		//Return the data, cipher algorithm used, and check sum value.
		return "<p>data: "+name+"<br>Name of Cipher Algorithm used: RSA CheckSum value: "+value;
	}
	
}